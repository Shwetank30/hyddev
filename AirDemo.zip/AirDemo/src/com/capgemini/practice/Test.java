package com.capgemini.practice;

public class Test {

	public static void main(String[] args) {
		Flight flight1 = new Flight();
		Flight flight2 = new Flight();
		flight1.add1Passenger();
		//System.out.println(flight2.passengers);
		Flight lax1 = new Flight();
		Flight lax2 = new Flight();
		// add passengers to both flights
		
		Flight lax3 = null;
		if(lax1.hasRoom(lax2))
			lax3=lax1.createNewWithBoth(lax2);
		// do some other work
		if(lax3 != null)
			System.out.println("Flights combined");
		Flight slcToNyc = new Flight();
		slcToNyc.setSeats(150);
		System.out.println(slcToNyc.getSeats());
	}

}
